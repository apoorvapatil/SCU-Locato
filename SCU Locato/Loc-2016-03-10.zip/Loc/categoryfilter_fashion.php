<!DOCTYPE html>
<html lang="en">
<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Share your stuff">
    <meta name="author" content="locato group 5">

    <title>Fashion</title>
    <link href="includes/css/locato.css" rel="stylesheet">
    <link href="includes/css/shop-homepage.css" rel="stylesheet">
    <link href="includes/css/glyphicons.css" rel="stylesheet">
    <link href="includes/css/font-awesome.css" rel="stylesheet">
    <link rel="stylesheet" href="includes/css/styles.css">
    <link rel="stylesheet" href="includes/css/locato-css.css">

    <link href="includes/css/business-frontpage.css" rel="stylesheet">

</head>

<body>

    <!-- Navigation -->
    <div class="navbar navbar-inverse navbar-fixed-top">
        <div class="container">

            <!-- .btn-navbar is used as the toggle for collapsed navbar content -->
            <button class="navbar-toggle" data-target=".navbar-responsive-collapse" data-toggle="collapse" type="button">
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>

            <a class="navbar-brand" href="home.php"><img id="locat" src="images/logo3.png" height="26px "alt="Locato"/></a>

            <div class="nav-collapse collapse navbar-responsive-collapse">
                <ul class="nav navbar-nav">
                    <li >
                        <a href="home.php">Home</a>
                    </li>

                    <li class="active">
                        <a href="categories1.php">Categories</a>
                    </li>

                    <li>
                        <a href="faq.php">FAQ</a>
                    </li>

                    <li >
                        <a href="contactus.php">Contact Us</a>
                    </li>
                </ul>


                <ul class="nav navbar-nav pull-right">
                    <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown"><span class="glyphicon glyphicon-user"></span> My Account <strong class="caret"></strong></a>

                        <ul class="dropdown-menu">
                            <li>
                                <a href="user-profile.php"><span class="glyphicon glyphicon-refresh"></span> Update Profile</a>
                            </li>
                            <li>
                                <a href="post.php"><span class="glyphicon glyphicon-briefcase"></span> Post Ad</a>
                            </li>

                            <li class="divider"></li>
                            <li>
                                <a href="home1.php"><span class="glyphicon glyphicon-off"></span> Sign out</a>
                            </li>
                        </ul>
                    </li>
                </ul><!-- end nav pull-right -->
            </div><!-- end nav-collapse -->

        </div><!-- end container -->
    </div><!-- end navbar -->
    <!-- Page Content -->

    <!-- Page Content -->
    <div class="container">
        <!-- Page Heading -->
        <div class="row">
            <div class="col-lg-8">
                <h1 class="page-header">Fashion
                    <small>Buy and Sell</small>
                </h1>
            </div>
            <!-- /.row -->

            <!-- Project One -->
            <div class="row">
                <div class="col-lg-7">
                    <a href="#">
                        <img class="img-responsive" src="images/fas1.jpg" alt="">
                    </a>
                </div>
                <div class="col-lg-5">
                    <h3>For sale</h3>
                    <h4>Pyjamas</h4>
                    <p>From fashion week coverage and the best dressed stars on the red carpet, to what's chic on the streets and trends to watch out for this season</p>
                    <a class="btn btn-primary" href="#">View Post <span class="glyphicon glyphicon-chevron-right"></span></a>
                </div>
            </div>
            <!-- /.row -->

            <hr>

            <!-- Project Two -->
            <div class="row">
                <div class="col-lg-7">
                    <a href="#">
                        <img class="img-responsive" src="images/fas2.jpg" alt="">
                    </a>
                </div>
                <div class="col-lg-5">
                    <h3>For sale</h3>
                    <h4>Pyjamas</h4>
                    <p>From fashion week coverage and the best dressed stars on the red carpet, to what's chic on the streets and trends to watch out for this season</p>
                    <a class="btn btn-primary" href="#">View Post<span class="glyphicon glyphicon-chevron-right"></span></a>
                </div>
            </div>
            <!-- /.row -->

            <hr>

            <!-- Project Three -->
            <div class="row">
                <div class="col-lg-7">
                    <a href="#">
                        <img class="img-responsive" src="images/fas3.jpg" alt="">
                    </a>
                </div>
                <div class="col-lg-5">
                    <h3>Dresses</h3>
                    <h4>Tops</h4>
                    <p>From fashion week coverage and the best dressed stars on the red carpet, to what's chic on the streets and trends to watch out for this season</p>
                    <a class="btn btn-primary" href="#">View Post<span class="glyphicon glyphicon-chevron-right"></span></a>
                </div>
            </div>
            <!-- /.row -->

            <hr>

            <!-- Project Four -->
            <div class="row">

                <div class="col-lg-7">
                    <a href="#">
                        <img class="img-responsive" src="images/fas4.jpg" alt="">
                    </a>
                </div>
                <div class="col-lg-5">
                    <h3>Skirts and hats</h3>
                    <h4>Skirts and hats</h4>
                    <p>From fashion week coverage and the best dressed stars on the red carpet, to what's chic on the streets and trends to watch out for this season</p>
                    <a class="btn btn-primary" href="#">View AD <span class="glyphicon glyphicon-chevron-right"></span></a>
                </div>
            </div>
            <!-- /.row -->

            <hr>

            <!-- Project Five -->
            <div class="row">
                <div class="col-lg-7">
                    <a href="#">
                        <img class="img-responsive" src="images/fas5.jpg" alt="">
                    </a>
                </div>
                <div class="col-lg-5">
                    <h3>Laptop bags</h3>
                    <h4>Bags</h4>
                    <p>From fashion week coverage and the best dressed stars on the red carpet, to what's chic on the streets and trends to watch out for this season</p>
                    <a class="btn btn-primary" href="#">View AD <span class="glyphicon glyphicon-chevron-right"></span></a>
                </div>
            </div>

        </div>
        <!-- /.row -->

        <hr>

        <!-- Pagination -->
        <div class="row text-center">
            <div class="col-lg-12">
                <ul class="pagination">
                    <li>
                        <a href="#">&laquo;</a>
                    </li>
                    <li class="active">
                        <a href="#">1</a>
                    </li>
                    <li>
                        <a href="#">2</a>
                    </li>
                    <li>
                        <a href="#">3</a>
                    </li>
                    <li>
                        <a href="#">4</a>
                    </li>
                    <li>
                        <a href="#">5</a>
                    </li>
                    <li>
                        <a href="#">&raquo;</a>
                    </li>
                </ul>
            </div>
        </div>
        <!-- /.row -->
    </div>

<?php
 include 'footer.php';
?>
   		<script src="http://code.jquery.com/jquery.js"></script>
        <!-- If no online access, fallback to our hardcoded version of jQuery -->
        <script>window.jQuery || document.write('<script src="includes/js/jquery-1.8.2.min.js"><\/script>')</script>
   		<script src="includes/js/locato-js.js"></script>
        <script src="includes/js/locato.js"></script>	



</body>

</html>

<!DOCTYPE html>
<html lang="en">
<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Share your stuff">
    <meta name="author" content="locato group 5">

    <title>Electronics</title>
    <link href="includes/css/locato.css" rel="stylesheet">
    <link href="includes/css/shop-homepage.css" rel="stylesheet">
    <link href="includes/css/glyphicons.css" rel="stylesheet">
    <link href="includes/css/font-awesome.css" rel="stylesheet">
    <link rel="stylesheet" href="includes/css/styles.css">
    <link rel="stylesheet" href="includes/css/locato-css.css">

    <link href="includes/css/business-frontpage.css" rel="stylesheet">

</head>
<body>


    <div class="container">
        <!-- Page Heading -->
        <div class="row">
            <div class="col-lg-8">
                <h1 class="page-header">Electronics
                    <small>Buy and Sell</small>
                </h1>
            </div>
            <!-- /.row -->

            <!-- Project One -->
            <div class="row">
                <div class="col-lg-7">
                    <a href="#">
                        <img class="img-responsive" src="images/elec1.jpg" alt="">
                    </a>
                </div>
                <div class="col-lg-5">
                    <h3>Computer for sale</h3>
                    <h4>Alex Ali</h4>
                    <p>Sears has the best electronic stores. Get electronic stores from Amazon Echo, HP, and Sprint</p>
                    <a class="btn btn-primary" href="#">View Post <span class="glyphicon glyphicon-chevron-right"></span></a>
                </div>
            </div>
            <!-- /.row -->

            <hr>

            <!-- Project Two -->
            <div class="row">
                <div class="col-lg-7">
                    <a href="#">
                        <img class="img-responsive" src="images/elec2.jpg" alt="">
                    </a>
                </div>
                <div class="col-lg-5">
                    <h3>HP Laptop for sale</h3>
                    <h4>Brynda Ros</h4>
                    <p>Sears has the best electronic stores. Get electronic stores from Amazon Echo, HP, and Sprint</p>
                    <a class="btn btn-primary" href="#">View Post<span class="glyphicon glyphicon-chevron-right"></span></a>
                </div>
            </div>
            <!-- /.row -->

            <hr>

            <!-- Project Three -->
            <div class="row">
                <div class="col-lg-7">
                    <a href="#">
                        <img class="img-responsive" src="images/elec3.jpg" alt="">
                    </a>
                </div>
                <div class="col-lg-5">
                    <h3>Electronic 3</h3>
                    <h4>Subheading</h4>
                    <p>Sears has the best electronic stores. Get electronic stores from Amazon Echo, HP, and Sprint</p>
                    <a class="btn btn-primary" href="#">View Post<span class="glyphicon glyphicon-chevron-right"></span></a>
                </div>
            </div>
            <!-- /.row -->

            <hr>

            <!-- Project Four -->
            <div class="row">

                <div class="col-lg-7">
                    <a href="#">
                        <img class="img-responsive" src="images/elec4.jpg" alt="">
                    </a>
                </div>
                <div class="col-lg-5">
                    <h3>Electronic 4</h3>
                    <h4>Subheading</h4>
                    <p>Sears has the best electronic stores. Get electronic stores from Amazon Echo, HP, and Sprint</p>
                    <a class="btn btn-primary" href="#">View AD <span class="glyphicon glyphicon-chevron-right"></span></a>
                </div>
            </div>
            <!-- /.row -->

            <hr>

            <!-- Project Five -->
            <div class="row">
                <div class="col-lg-7">
                    <a href="#">
                        <img class="img-responsive" src="images/elec5.jpg" alt="">
                    </a>
                </div>
                <div class="col-lg-5">
                    <h3>Electronic 5</h3>
                    <h4>Subheading</h4>
                    <p>Sears has the best electronic stores. Get electronic stores from Amazon Echo, HP, and Sprint</p>
                    <a class="btn btn-primary" href="#">View AD <span class="glyphicon glyphicon-chevron-right"></span></a>
                </div>
            </div>

        </div>
        <!-- /.row -->

        <hr>

        <!-- Pagination -->
        <div class="row text-center">
            <div class="col-lg-12">
                <ul class="pagination">
                    <li>
                        <a href="#">&laquo;</a>
                    </li>
                    <li class="active">
                        <a href="#">1</a>
                    </li>
                    <li>
                        <a href="#">2</a>
                    </li>
                    <li>
                        <a href="#">3</a>
                    </li>
                    <li>
                        <a href="#">4</a>
                    </li>
                    <li>
                        <a href="#">5</a>
                    </li>
                    <li>
                        <a href="#">&raquo;</a>
                    </li>
                </ul>
            </div>
        </div>
        <!-- /.row -->
    </div>

<?php
 include 'footer.php';
?>
   		<script src="http://code.jquery.com/jquery.js"></script>
        <!-- If no online access, fallback to our hardcoded version of jQuery -->
        <script>window.jQuery || document.write('<script src="includes/js/jquery-1.8.2.min.js"><\/script>')</script>
   		<script src="includes/js/locato-js.js"></script>
        <script src="includes/js/locato.js"></script>	


</body>

</html>

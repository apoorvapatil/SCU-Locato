$( document ).ready(function() {
    
    if($('#abc').text()!="")
    {   alert("Mansi123");
    	$('#login-form').show();
    }
});




$("#login12").click(function(){
     $('#login-form').show();


});


function loginValidate(){
		
	var username=document.getElementById("username").value;
	var pwd=document.getElementById("password").value;
	var errorText=document.getElementById("errorText").innerHTML;
	console.log("u",username);
	if(username=="" || username==null || pwd=="" || pwd==null){
	document.getElementById("errorText").innerHTML="Please enter username & password";
	return false;
	}
	return true;

};



/*function loginPoster(){
	alert("Hi3435");
 var username = $('#username').val();
            var password= $('#password').val();
            var data = 'username=' + name + '&password=' + password;
            $.ajax({
                url: 'home.php',
                type: "POST",
                data: data,
                cache: false,
                dataType: "JSON",
                success: function(data){
                    if(data.error_username){
                        alert(data.error_name);
                        return false;
                    }
                    if(data.error_password){
                        alert(data.error_email);
                        return false;
                    }
                }
            });

};*/
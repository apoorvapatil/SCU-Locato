		<footer>
			<div class="container">
        <div class="row">

            <div class="col-sm-1">
               <img src="images/footer-mission.png" height="68px"alt="scu mission logo" style="float: left;"/>
            </div><!-- end col-sm-1 -->

                <div class="col-sm-4">
                <h5> Location</h5>
                <h6>
                    500 El Camino Real,<br/>
                    Santa Clara, CA 95053<br/>
                    (408) 554-4000<br/></h6>
            </div><!-- end col-sm-3 -->

            <!--
            <div class="col-sm-3" align="center">
                <h5>Copyright &copy; 2016 Locato</h5>
            </div><!-- end col-sm-3 -->


            <div class="col-md-4 pull-right">



                <ul class=" socials list-inline ">
                    <li>
                        <a target="_blank" href="https://www.facebook.com/SantaClaraUniversity" class="btn-social" ><i class="fa fa-facebook"></i></a>
                    </li>

                        <li>
                    <a href="https://www.linkedin.com/edu/santa-clara-university-17914" class="btn-social" ><i class="fa fa-linkedin"></i></a>
                </li>
                    <li>
                        <a  target="_blank"  href="https://twitter.com/SantaClaraUniv" class="btn-social" ><i class="fa fa-twitter"></i></a>
                    </li>



                        <li>
                            <a target="_blank"  href="https://www.pinterest.com/santaclarauniv/" class="btn-social" ><i class="fa fa-pinterest"></i></a>
                        </li>
                    <li>
                        <a target="_blank"  href="https://instagram.com/santaclarauniversity/" class="btn-social" ><i class="fa fa-instagram"></i></a>
                    </li>

                </ul>
                    <div >
                <h5>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Copyright &copy; 2016 Locato</h5>
                    </div>
            </div><!--end of col-sm-5-->

        </div><!-- end row -->
    </div><!-- end container -->
		</footer>

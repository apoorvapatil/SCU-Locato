
        <div class="container" id="main">
         <div class="navbar navbar-inverse navbar-fixed-top">
        <div class="container">

            <!-- .btn-navbar is used as the toggle for collapsed navbar content -->
            <button class="navbar-toggle" data-target=".navbar-responsive-collapse" data-toggle="collapse" type="button">
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>

            <a class="navbar-brand" href="home.html"><img id="locat" src="images/logo3.png" height="26px "alt="Locato"/></a>

            <div class="nav-collapse collapse navbar-responsive-collapse">
                <ul class="nav navbar-nav">
                    <li class="active">
                        <a href="home.html">Home</a>
                    </li>

                    <li>
                        <a href="categories1.html">Categories</a>
                    </li>

                    <li>
                        <a href="faq.html">FAQ</a>
                    </li>

                    <li>
                        <a href="contactus.html">Contact Us</a>
                    </li>



                </ul>


                <ul class="nav navbar-nav pull-right">
                    <li >
                        <p   id="login12">

                            <span class="glyphicon glyphicon-user"></span> Login <strong class="caret"></strong></p>
</li>
                    </ul>

            </div><!-- end nav-collapse -->

        </div><!-- end container -->
    </div><!-- end navbar -->

<!DOCTYPE html>
<html lang="en">
<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Share your stuff">
    <meta name="author" content="locato group 5">

    <title>User Profile</title>
    <link href="includes/css/locato.css" rel="stylesheet">
    <link href="includes/css/shop-homepage.css" rel="stylesheet">
    <link href="includes/css/glyphicons.css" rel="stylesheet">
    <link href="includes/css/font-awesome.css" rel="stylesheet">
    <link rel="stylesheet" href="includes/css/styles.css">
    <link rel="stylesheet" href="includes/css/locato-css.css">

    <link href="includes/css/business-frontpage.css" rel="stylesheet">

</head>
	<body>

<?php

 session_start();
if(isset($_GET['action'])=='logout'){
     #echo "Hi1";
   unset($_SESSION['username']);
session_destroy();

header("Location: home.php");
exit;
 
}

if (isset($_SESSION['username'])){
 #echo "Hi2";
 include 'header1.php';
}
else{
     #echo "Hi3";
 include 'header.php';
}

?>




    <!-- User profile content starts here -->
    <br /> <br /> <br />
    <div class="container">
      <div class="row">
                <div class="col-sm-3 feature"> </div>

				<div class="col-sm-3 feature">
                   <img src="images/prof1.jpg" alt="CSS3" class="img-circle">
                </div>
                <div class="col-sm-3 feature">
                   <h3>John Grid </h3>
				    <p>Grad student, coding expert.</p>
                    <h4>Contact Information</h4>
                    <p> <h4><span class="glyphicon glyphicon-phone"></span>Phone:123-456-4545</h4>
                   <h4><span class="glyphicon glyphicon-envelope"></span> Email: a.b@scu.edu</h4></p>
                    <p><h4><span class="glyphicon glyphicon-home"></span>Dorm:Loyola Hall</h4></p>
                </div>
                <div class="col-sm-3 feature"> </div>

       </div>
     <div class="row" id="featuresHeading">
				<div class="col-12">
					<h2 style="text-align:center">My Posts</h2>

				</div><!-- end col-12 -->
			</div><!-- end featuresHeading -->
    <div class="row" id="features">
				<div class="col-sm-3 feature">

					<div class="panel">
						<span class="glyphicon glyphicon-pencil"></span>
                    <span class="glyphicon glyphicon-remove-sign"></span> <br />
						<img src="images/badge_pic1.jpg" alt="HTML5" >

						<p>Little Shiro needs a house.</p>


					</div><!-- end panel -->
				</div><!-- end feature -->

				<div class="col-sm-3 feature">
					<div class="panel">
						<span class="glyphicon glyphicon-pencil"></span>
                    <span class="glyphicon glyphicon-remove-sign"></span> <br />
						<img src="images/badge_pic2.png" alt="HTML5" >

						<p>May the Force be with you.</p>


					</div><!-- end panel -->
				</div><!-- end feature -->

				<div class="col-sm-3 feature">
					<div class="panel">
						<span class="glyphicon glyphicon-pencil"></span>
                    <span class="glyphicon glyphicon-remove-sign"></span> <br />
						<img src="images/badge_pic3.jpg" alt="HTML5" >

						<p>Ride in syle!</p>


					</div><!-- end panel -->
				</div><!-- end feature -->

				<div class="col-sm-3 feature">
					<div class="panel">
						<span class="glyphicon glyphicon-pencil"></span>
                    <span class="glyphicon glyphicon-remove-sign"></span> <br />
						<img src="images/badge_pic4.jpg" alt="HTML5" >

						<p>Flaunt your pride, Broncos!</p>


					</div><!-- end panel -->
				</div><!-- end feature -->

			</div><!-- end features -->

    <!-- Pagination -->
        <div class="row text-center">
            <div class="col-lg-12">
                <ul class="pagination">
                    <li>
                        <a href="#">&laquo;</a>
                    </li>
                    <li class="active">
                        <a href="#">1</a>
                    </li>
                    <li>
                        <a href="#">2</a>
                    </li>
                    <li>
                        <a href="#">3</a>
                    </li>
                    <li>
                        <a href="#">4</a>
                    </li>
                    <li>
                        <a href="#">5</a>
                    </li>
                    <li>
                        <a href="#">&raquo;</a>
                    </li>
                </ul>
            </div>
        </div>
        <!-- /.row -->






 </div>
    <!-- User profile content ends here -->
         </div> <!-- Main container ends -->

	<?php
 include 'footer.php';
?>
        <script src="http://code.jquery.com/jquery.js"></script>

        <!-- If no online access, fallback to our hardcoded version of jQuery -->
        <script>window.jQuery || document.write('<script src="includes/js/jquery-1.8.2.min.js"><\/script>')</script>

        <script src="includes/js/locato.js"></script>


	</body>
</html>

